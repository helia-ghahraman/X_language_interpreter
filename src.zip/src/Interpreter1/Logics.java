package Interpreter1;

public class Logics {
}

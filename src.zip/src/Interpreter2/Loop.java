package Interpreter2;

public class Loop extends Statement {
    public Loop(String[] tokens) {
        execute(tokens);
    }

    //*********************************************************
    private void loop() {
        //Todo add something here
    }

    @Override
    public void execute(String[] tokens) {
        //Todo add something here
    }
}

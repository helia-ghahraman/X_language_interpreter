package Interpreter2;

public interface Executable {
    void execute(String[] tokens);
}

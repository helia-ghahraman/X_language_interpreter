package Interpreter2;

public abstract class Statement implements Executable {
}
